<?php

class Login
{
    public $id;
    public $title;
    public $picture;
}