<?php

function checkLogin(string $email, string $password) {
    global $pdo;
    $sth = $pdo->prepare('SELECT email, role FROM users WHERE email = ? AND password = ?');
    $sth->bindParam(1, $email);
    $sth->bindParam(2, $password);
    $sth->setFetchMode(PDO::FETCH_CLASS, User::class);
    $user = $sth->fetch();
    $sth->execute();
    return $category = $sth->fetch();

}