<?php
require '../Modules/Categories.php';
require '../Modules/Products.php';
require '../Modules/register.php';
require '../Modules/Database.php';
require '../Modules/User.php';

$request = $_SERVER['REQUEST_URI'];
$params = explode("/", $request);
$title = "HealthOne";
$titleSuffix = "";
session_start();

switch ($params[1]) {
    case 'categories':
        $titleSuffix = ' | Categories';
        
        if (isset($_GET['category_id'])) {
            $categoryId = $_GET['category_id'];
            $products = getProducts($categoryId);
            $name = getCategoryName($categoryId);

            if (isset($_GET['product_id'])) {
                $productId = $_GET['product_id'];
                $product = getProduct($productId);
                $titleSuffix = ' | ' . $product->name;
                if(isset($_POST['name']) && isset($_POST['review'])) {
                    saveReview($_POST['name'],$_POST['review']);
                    $reviews=getReviews($productId);
                }
                // TODO Zorg dat je hier de product pagina laat zien
                include_once "../Templates/product.php";
            } else {
                // TODO Zorg dat je hier alle producten laat zien van een categorie
                include_once "../Templates/products.php";
            }
        } else {
            // TODO Toon de categorieen
            $categories = getCategories();
            var_dump($categories);
            include_once "../Templates/categories.php";
        }
        break;
    case'contacts':
        $titleSuffix = '| Contact';
        include_once "../Templates/contacts.php";
        break;

    case'register':

        $titleSuffix = ' | Register';
        if (isset($_POST['register'])){
           // var_dump($_POST);die;
            $result = makeRegistration();
            switch ($result){
                case 'SUCCESS':
                    header("Location: /home");
                    break;
                case 'INCOMPLETE':
                    $message="Niet alle velden zijn ingevuld";
                    include_once "../Templates/register.php";
                    break;
            }
        }
        else{
            include_once "../Templates/register.php";
        }
        break;
    case 'member':
        include_once('../Templates/member.php');
        break;

    case 'login':
        $titleSuffix=' | Login';

        if (isset($_POST['login'])){
            $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
            $password = filter_input(INPUT_POST, "password");
            $user = checkLogin($email, $password);
            if (Suser == false) {
                $error['title'] = "incorrect!";
                $error['message'] = "incorrect credentials.";

            }
            else {
                $S_SESSION['login'] = true;
                $S_SESSION['role'] = $user->role;
                $S_SESSION['email'] = $user->email;
            }

        }
        include_once "login.php";
        break;
        case 'logout';
        session_destroy();
        header("location: /");
        break;

    default:
        $titleSuffix = ' | Home';
        include_once "../Templates/home.php";
}

function getTitle() {
    global $title, $titleSuffix;
    return $title . $titleSuffix;
}
