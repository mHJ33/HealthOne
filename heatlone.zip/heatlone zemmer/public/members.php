<?php
global $params;
//checken of role admin is
if (!isMember()){
    logout();
    header("location:/home");
} else {
    switch ($params[2]){
        case 'home':
            include_once "../Templates/member.php/home.php";
            break;
        case 'products': case 'profile':case 'editprofile':case 'changepassword':
    }
}
