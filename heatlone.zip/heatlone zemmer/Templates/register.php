<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
?>
<body>
<div class="container">
    <?php
    include_once ('defaults/header.php');
    include_once ('defaults/menu.php');
    include_once ('defaults/pictures.php');
    ?>

    <form class="row g-3" method="post">
        <div class="col-md-12 col-lg-6">
            <label for="inputEmail4" class="form-label">Email</label>
            <input type="email" name="email" class="form-control" id="inputEmail4">
        </div>
        <div class="col-md-12 col-lg-6">
            <label for="inputPassword4" class="form-label">Password</label>
            <input type="password" name="password" class="form-control" id="inputPassword4">
        </div>
        <div class="col-md-6 ">
            <label for="inputAddress" class="form-label">First name</label>
            <input type="text" name="firstName" class="form-control" id="inputAddress" placeholder="Piet">
        </div>
        <div class="col-md-6">
            <label for="inputAddress2" class="form-label">Last name</label>
            <input type="text" name="lastName" class="form-control" id="inputAddress2" placeholder="van Vliet">
        </div>

        <div class="col-12">
            <button type="submit" name="register" class="btn btn-primary">Sign in</button>
        </div>
    </form>
    <?php
    include_once ('defaults/footer.php');
    ?>
</div>
</body>
</html>
