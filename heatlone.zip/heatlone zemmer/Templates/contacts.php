<!DOCTYPE html>
<html>
<?php
include_once('defaults/head.php');
?>
<body>
<div class="container">
    <?php
    include_once ('defaults/header.php');
    include_once ('defaults/menu.php');
    include_once ('defaults/pictures.php');
    ?>

<div class="center">
    <h4>Sportcenter HealthOne</h4>
    Wij zijn geopend van
    <div class="contactIntro">
        <h4>Sportcenter HealthOne</h4>
        <hr>
        <strong>Welkom bij ons contact pagina! <br> </strong>
        <p>op deze pagina word ons contact gevens, locatie en openingstijden weergeven.</p><br>
    </div>
    <div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=%20Tinwerf%2010,%202544%20ED%20Den%20Haag&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.embedgooglemap.net/blog/divi-discount-code-elegant-themes-coupon/"></a><br><style>.mapouter{margin: auto;text-align:right;height:500px;width:600px;}</style><a href="https://www.embedgooglemap.net">google map html generator</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div></div>
    <hr>
    <div class="icons">
        <i class="fas fa-mobile-alt fs-4">+31611143065</i>
        <i class="far fa-paper-plane fs-4">healthonecontact@gmail.com</i>
    </div>
</div>

    <hr>
    <?php
    include_once ('defaults/footer.php');
    ?>
</div>
</body>
</html><?php
