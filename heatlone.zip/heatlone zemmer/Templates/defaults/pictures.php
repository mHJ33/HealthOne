<figure>
    <img class="banner-img img-fluid" src='/img/redgymbanner.jpg' />
</figure>


