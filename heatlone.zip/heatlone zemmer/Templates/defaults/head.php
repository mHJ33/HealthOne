<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title><?= getTitle() ?></title>
    <link rel="stylesheet" href="/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="/css/style.css"/>
    <script src="https://kit.fontawesome.com/bc9e2b52bc.js" crossorigin="anonymous"></script>

    <script src="/js/bootstrap.bundle.js"></script>
</head>